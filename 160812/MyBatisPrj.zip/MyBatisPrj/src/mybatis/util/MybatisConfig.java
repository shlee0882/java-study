package mybatis.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MybatisConfig {

	private static SqlSessionFactory factory = null;

	static {
		InputStream inputStream = null;

		String resource = "mybatis/config/SqlMapConfig.xml";

		try {
			inputStream = Resources.getResourceAsStream(resource);
			System.out.println(inputStream);
			SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
			factory = builder.build(inputStream);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

	}

	public static SqlSession getSqlSession() {
		return factory.openSession();
	}

	public static void closeSqlSession(SqlSession session) {
		if (session != null) {
			session.close();
		}
	}

	public static void closeSqlSession(boolean flag, SqlSession session) {

		if (session != null) {

			if (flag) {
				session.commit();
			} else {
				session.rollback();
			}
			session.close();
		}
	}

}