package user.dao;

import org.apache.ibatis.session.SqlSession;

import mybatis.util.MybatisConfig;
import user.vo.UserVO;

public class UserDaoImpl  {
	
	
	public UserVO read(String id) {
		SqlSession session = null;
		try{
			session = MybatisConfig.getSqlSession();
			UserVO user  = session.selectOne("userNS.selectUserById",id);
			return user;
		}finally {
			MybatisConfig.closeSqlSession(session);				
		}
	}
	
}










